import React, { useEffect, useState } from "react";
import mainContainerStyles from "../../../css/mainContainer.module.css";
import {
  Avatar,
  Badge,
  Button,
  IconButton,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  TextField,
} from "@mui/material";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import KeyboardArrowDownOutlinedIcon from "@mui/icons-material/KeyboardArrowDownOutlined";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
import ImportContactsOutlinedIcon from "@mui/icons-material/ImportContactsOutlined";
import { useLocation, useNavigate } from "react-router-dom";
import searchIcn from "../../../../../src/img/search.svg";

const MainContainer = (props) => {
  const [contentDevOrAdmin, setContentDevOrAdmin] = useState(true);
  const [anchorEl, setAnchorEl] = useState(null);
  const [topTitle, setTopTitle] = useState("Dashboard");
  const open = Boolean(anchorEl);
  const location = useLocation();
  useEffect(() => {
    if (location.pathname) {
      const path = location.pathname.split("/");
      const title = path.includes("ConceptTreeView")
        ? path[path.length - 2].replaceAll("%20", " ")
        : path[path.length - 1].replaceAll("%20", " ");
      setTopTitle(
        title === "template"
          ? "Dashboard"
          : title === "content approval"
          ? "Content Approval"
          : title === "template"
          ? "Dashboard"
          : title === "global training approval"
          ? "Global Training Approval"
          : title === "template"
          ? "Dashboard"
          : title === "concept tree approval"
          ? "Concept Tree Approval"
          : title === "template"
          ? "Dashboard"
          : title === "view concept tree"
          ? "View Concept Tree"
          : title === "template"
          ? "Dashboard"
          : title === "csp"
          ? "Change Student Profile"
          : title === "template"
          ? "Dashboard"
          : title === "branchplan"
          ? "Plan"
          : title === "template"
          ? "Dashboard"
          : title === "branchsection"
          ? "Sections"
          : title === "template"
          ? "Dashboard"
          : title === "teacherId"
          ? "Academic Staff"
          : title === "template"
          ? "Dashboard"
          : title === "student"
          ? "Students"
          : title === "template"
          ? "Dashboard"
          : title === "tokenList"
          ? "Tokens"
          : title === "template"
          ? "Dashboard"
          : title === "logo"
          ? "Branch Logo"
          : title === "template"
          ? "Dashboard"
          : title === "TokenList"
          ? "Tokens"
          : title === "template"
          ? "Dashboard"
          : title === "admin users"
          ? "Admin Users"
          : title === "template"
          ? "Dashboard"
          : title === "upload content"
          ? "Upload Content"
          : title === "template"
          ? "Dashboard"
          : title === "global training"
          ? "Global Training"
          : title === "template"
          ? "Dashboard"
          : title === "associate concepts"
          ? "Associate Concepts"
          : title === "template"
          ? "Dashboard"
          : title === "blue print"
          ? "Blue Print"
          : title === "template"
          ? "Dashboard"
          : title === "CreateManagement"
          ? "Create Management"
          : title === "template"
          ? "Dashboard"
          : title === "add Management"
          ? "Add Management"
          : title === "template"
          ? "Dashboard"
          : title === "academicid"
          ? "Academic Id"
          : title === "template"
          ? "Dashboard"
          : title === "createschool"
          ? "Create School"
          : title === "template"
          ? "Dashboard"
          : title === "CreateChapter"
          ? "Create Chapter"
          : title === "template"
          ? "Dashboard"
          : title === "AddTeacherFiles"
          ? "Add Teacher Files"
          : title === "template"
          ? "Dashboard"
          : title === "CreateTrainingCategory"
          ? "Create Training Category"
          : title === "template"
          ? "Dashboard"
          : title === "CreateTraining"
          ? "Create Training"
          : title === "template"
          ? "Dashboard"
          : title === "addBranch"
          ? "Branches"
          : title === "template"
          ? "Dashboard"
          : title === "addbranch"
          ? "Branches"
          : title === "template"
          ? "Dashboard"
          : title === "GlobalTrainingApprovalApproved"
          ? "Global Training Approval "
          : title === "template"
          ? "Dashboard"
          : title === "Edit Concept"
          ? "Create/Edit Concept"
          : title === "template"
          ? "Dashboard"
          : title === "StudentFileApproval"
          ? "Student File Approval"
          : title === "template"
          ? "Dashboard"
          : title === "TeacherFileApproval"
          ? "Teacher File Approval"
          : title === "template"
          ? "Dashboard"
          : title === "Content Approval"
          ? "Content Approval"
          : title === "template"
          ? "Dashboard"
          : title === "GlobalTrainingApprovalRejected"
          ? "Global Training Approval "
          : title === "template"
          ? "Dashboard"
          : title === "ConceptTreeApprovalRejected"
          ? "Concept Tree Approval "
          : title === "template"
          ? "Dashboard"
          : title === "ConceptTreeApprovalPending"
          ? "Concept Tree Approval "
          : title === "template"
          ? "Dashboard"
          : title === "GlobalTrainingApprovalApproved"
          ? "Global Training Approval "
          : title === "template"
          ? "Dashboard"
          : title === "ContentApprovalRejected"
          ? "Content Approval "
          : title === "template"
          ? "Dashboard"
          : title === "ContentApprovalApproved"
          ? "Content Approval "
          : title === "template"
          ? "Dashboard"
          : title === "CreateTeacher"
          ? "Add Academic Staff"
          : title === "template"
          ? "Dashboard"
          : title === "Edit Sub & Root Concepts"
          ? "Create/Edit Sub & Root Concepts"
          : title === "template"
          ? "Dashboard"
          : title === "contentapprovalviewfile"
          ? "Content Approval"
          : title === "template"
          ? "Dashboard"
          : title === "ContentApprovalTeacherViewFile"
          ? "Content Approval"
          : title === "template"
          ? "Dashboard"
          : title === "study"
          ? "Study"
          : title === "template"
          ? "Dashboard"
          : title === "enrich"
          ? "Enrich"
          : title === "template"
          ? "Dashboard"
          : title === "teacherid"
          ? "Academic Staff"
          : title
      );
    }
  }, [location.pathname]);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = (e, iconValue) => {
    const value = e.target.innerText;
    if (value || iconValue) {
      if (value === "Profile" || iconValue === "Profile") {
        navigate("/dashboard/TeacherProfile", {
          state: { id: 1, value: "profile" },
        });
      } else if (value === "Current Access" || iconValue === "Current Access") {
        navigate("/dashboard/TeacherProfile", {
          state: { id: 2, value: "currentAccess" },
        });
      }
    }
    setAnchorEl(null);
  };
  const isTeacher = localStorage.getItem("role") === "TEACHER";
  const firstName = localStorage.getItem("firstName");
  const lastName = localStorage.getItem("lastName");
  const handleToggle = () => {
    setContentDevOrAdmin(contentDevOrAdmin ? false : true);
  };

  const navigate = useNavigate();
  const tempMenu = localStorage.getItem("menus");
  const Navmenu = JSON.parse(tempMenu);
  return (
    <div className={mainContainerStyles.main_container}>  
      <header
        style={{ marginLeft: "-15px", paddingLeft: "15px" }}
        className={mainContainerStyles.header}
      >
        {/*  added by sg */}
        {/* <h3 className={mainContainerStyles.header_title}>{props.headerTitle ? props.headerTitle : 'Registered Schools'}</h3> */}

        {isTeacher ? (
          <>
            <h3 className={mainContainerStyles.header_title}>
              Welcome to {firstName} {lastName}
            </h3>
            <div className={mainContainerStyles.header_teacher}>
              <TextField
                sx={{
                  width: { sm: 200, md: 300 },
                  "& .MuiInputBase-root": {
                    left: "-48px",
                    width: "342px",
                    height: "44px",
                    background: " #F3F2FF",
                    borderRadius: "10px",
                    opacity: 1,
                  },
                }}
                type={"text"}
                placeholder={"Search anything...."}
                InputProps={{
                  startAdornment: (
                    <IconButton>
                      <img
                        src={searchIcn}
                        style={{
                          verticalAlign: "top",
                          fontSize: "large",
                          color: "#27334E",
                        }}
                        aria-hidden="true"
                      />
                    </IconButton>
                  ),
                }}
                size={"small"}
              />
              <div className={mainContainerStyles.teacher_badge}>
                <Badge
                  variant="dot"
                  sx={{ color: "#403b97", fontSize: "1.5vw" }}
                  color={"secondary"}
                >
                  <NotificationsNoneOutlinedIcon
                    style={{ fontSize: "1.5vw" }}
                  />
                </Badge>
              </div>
              <Button
                id="basic-button"
                aria-controls={open ? "basic-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={open ? "true" : undefined}
                onClick={handleClick}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "row",
                  columnGap: "10px",
                  padding: "10px",
                }}
              >
                <Avatar
                  sx={{
                    background: "orange",
                    width: "2.8vw",
                    height: "2.8vw",
                    fontSize: "1.4vw",
                  }}
                >
                  {firstName[0]?.toUpperCase()}
                </Avatar>
                <div className={mainContainerStyles.profile_Name}>
                  <div className={mainContainerStyles.teacher_name}>
                    {firstName} {lastName}
                  </div>
                  <div
                    style={{
                      color: "blue",
                      display: "flex",
                      justifyContent: "start",
                      width: "100%",
                      fontSize: "1.2vw",
                    }}
                  >
                    {localStorage.getItem("role")}
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    alignItems: "end",
                    rowGap: "20px",
                  }}
                >
                  <div>
                    {open ? (
                      <KeyboardArrowUpIcon
                        style={{ fontSize: "1.5vw", color: "black" }}
                      />
                    ) : (
                      <KeyboardArrowDownOutlinedIcon
                        style={{ fontSize: "1.5vw", color: "black" }}
                      />
                    )}
                  </div>
                  <div />
                </div>
              </Button>
              <Menu
                id="basic-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={(e) => handleClose(e)}
                MenuListProps={{
                  "aria-labelledby": "basic-button",
                }}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: "visible",
                    filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
                    mt: 1.5,
                    "& .MuiAvatar-root": {
                      width: 32,
                      height: 32,
                      ml: -0.5,
                      mr: 1,
                    },
                    "&:before": {
                      content: '""',
                      display: "block",
                      position: "absolute",
                      top: 0,
                      right: 20,
                      width: 10,
                      height: 12,
                      bgcolor: "background.paper",
                      transform: "translateY(-50%) rotate(45deg)",
                      zIndex: 0,
                    },
                  },
                }}
                transformOrigin={{ horizontal: "right", vertical: "top" }}
                anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
              >
                <MenuItem onClick={(e) => handleClose(e)}>
                  <ListItemIcon onClick={(e) => handleClose(e, "Profile")}>
                    <AccountCircleOutlinedIcon
                      fontSize="small"
                      sx={{ color: "#403b97" }}
                    />
                  </ListItemIcon>
                  <ListItemText sx={{ color: "#403b97" }}>Profile</ListItemText>
                </MenuItem>
                <MenuItem onClick={(e) => handleClose(e)}>
                  <ListItemIcon
                    onClick={(e) => handleClose(e, "Current Access")}
                  >
                    <ImportContactsOutlinedIcon
                      fontSize="small"
                      sx={{ color: "#403b97" }}
                    />
                  </ListItemIcon>
                  <ListItemText sx={{ color: "#403b97" }}>
                    Current Access
                  </ListItemText>
                </MenuItem>
              </Menu>
            </div>
          </>
        ) : (
          <>
            <h3 className={mainContainerStyles.header_title}>
              {/*{props.headerTitle ? props.headerTitle : "Dashboard"}*/}
              {topTitle}
            </h3>
            <i className="fa-solid fa-anchor-circle-check"></i>
            <span
              className={`${mainContainerStyles.link_icon_superAdmin} ${mainContainerStyles.superAdmin_icon}`}
              id="user_icon"
            >
              <i className="fa-regular fas fa-user-cog"></i>
              <span
                id="userName"
                className={mainContainerStyles.superAdmin_link_text}
              >
                {localStorage.getItem("role")}
                {/* CONTENT ADMIN */}
              </span>
            </span>
          </>
        )}

        {/* <div
          className={mainContainerStyles.header_button_container}
          id="header-btn-container"
          onClick={handleToggle}
        >
          <button
            className={`${mainContainerStyles.header_button} ${mainContainerStyles.content_dev}`}
            id="content-dev"
          >
            Content Dev
          </button>
          <button className={mainContainerStyles.header_button}>Admin</button>
          <button
            className={
              contentDevOrAdmin
                ? mainContainerStyles.slider
                : `${mainContainerStyles.slider} ${mainContainerStyles.slider_right}`
            }
            id="header-btn-slider"
          >
            {contentDevOrAdmin ? "Content Dev" : "Admin"}
          </button>
        </div> */}
      </header>
      {/* dashboard content for various pages - start */}
      {props.children}
      {/* dashboard content for various pages - end */}
    </div>
  );
};

export default MainContainer;
