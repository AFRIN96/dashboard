import React, { useEffect, useState } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import dashboardContentStyles from "../../../css/dashboardContent.module.css";
import CordinatorOTPVerificationModal from "./Modals/CordinatorOTPVerificationModal";

const DashboardContents = () => {
  const [second, setSecond] = useState(900);
  const navigate = useNavigate();
  let [intervalId, setIntervalId] = useState(null);
  const [modifiedDate, setModifiedDate] = useState({});

  // added by afrin
  const [openVerificationModal, setOpenVerificationModal] = useState(false);
  const [isOTP, setIsOTP] = useState(false);
  //
  
  useEffect(() => {
    setIntervalId(
      setInterval(() => {
        setSecond((prevSec) => prevSec - 1);
      }, 1000)
    );
  }, []);

  // useEffect(()=> {
  //   GetLastModifiedAt(setModifiedDate);
  //   return () => {};
  // } , [])

  useEffect(() => {
    if (second <= 0) {
      if (intervalId) {
        clearInterval(intervalId);
        localStorage.removeItem("token");
        // navigate("/login", { state: { id: 7, color: "green" } });
      }
    }
  }, [second]);

  const timeOut = () => {
    const minutes = Math.floor(second / 60);

    // 👇️ get remainder of seconds
    const seconds = second % 60;

    function padTo2Digits(num) {
      return num.toString().padStart(2, "0");
    }

    // ✅ format as MM:SS
    return `${padTo2Digits(minutes)}:${padTo2Digits(seconds)}`;
  };

  return (
    <section className={dashboardContentStyles.dashboard}>
      <div className={dashboardContentStyles.dashboard_link}>
        home{" "}
        <button onClick={() => setOpenVerificationModal(true)}>Open</button>
      </div>
      {openVerificationModal && (
        <CordinatorOTPVerificationModal
          visible={openVerificationModal}
          hide={() => setOpenVerificationModal(false)}
          // number={phoneNumber}
          setIsOTP={setIsOTP}
        />
      )}
      <Outlet />
    </section>
  );
};

export default DashboardContents;
